"""Calculator application module."""
